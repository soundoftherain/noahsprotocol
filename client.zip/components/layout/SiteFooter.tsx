import { Link } from "react-router-dom";
import { Disc, Instagram, Radio, Twitter } from "lucide-react";

const socials = [
  {
    name: "X",
    icon: Twitter,
    href: "https://x.com",
  },
  {
    name: "Instagram",
    icon: Instagram,
    href: "https://instagram.com",
  },
  {
    name: "Soundwaves",
    icon: Radio,
    href: "https://soundcloud.com",
  },
  {
    name: "Collective",
    icon: Disc,
    href: "https://discord.com",
  },
];

export function SiteFooter() {
  return (
    <footer className="relative mt-24 border-t border-white/10 bg-white/5/20">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
      <div className="mx-auto grid max-w-6xl gap-12 px-6 pb-12 pt-16 md:grid-cols-[1.3fr,1fr,1fr] md:px-8">
        <div className="max-w-md space-y-4">
          <Link to="/" className="inline-flex items-center gap-3">
            <div className="rounded-2xl bg-gradient-to-br from-primary/90 via-primary to-secondary/70 p-3 text-background shadow-aurora ring-1 ring-white/30">
              <span className="text-lg font-semibold">NA</span>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.4em] text-muted-foreground">
                Noah&apos;s Art
              </p>
              <p className="text-lg font-semibold text-white">
                Living Art Universe
              </p>
            </div>
          </Link>
          <p className="text-sm text-muted-foreground">
            A modern myth where every chapter is minted in color, emotion, and
            collective imagination. Hold Ark Coin to unlock evolving stories,
            character drops, and exclusive IRL transmissions.
          </p>
        </div>
        <div className="grid gap-4 text-sm text-muted-foreground">
          <h3 className="text-sm font-semibold uppercase tracking-[0.3em] text-white">
            Navigate
          </h3>
          <div className="grid gap-3 text-white/80">
            <a className="hover:text-white/100" href="#universe">
              Immersive Universe
            </a>
            <a className="hover:text-white/100" href="#timeline">
              Storyline Timeline
            </a>
            <a className="hover:text-white/100" href="#characters">
              Character Atlas
            </a>
            <a className="hover:text-white/100" href="#ark-coin">
              Ark Coin Portal
            </a>
          </div>
        </div>
        <div className="grid gap-4 text-sm text-muted-foreground">
          <h3 className="text-sm font-semibold uppercase tracking-[0.3em] text-white">
            Connect
          </h3>
          <div className="flex flex-wrap gap-2">
            {socials.map(({ name, icon: Icon, href }) => (
              <a
                key={name}
                href={href}
                target="_blank"
                rel="noreferrer"
                className="group flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/80 transition hover:border-secondary/60 hover:bg-secondary/10 hover:text-white"
              >
                <Icon className="h-4 w-4" />
                {name}
              </a>
            ))}
          </div>
          <p className="text-xs text-white/40">
            © {new Date().getFullYear()} Noah&apos;s Art. Ark Coin smart contracts
            audited by Lattice Labs.
          </p>
        </div>
      </div>
    </footer>
  );
}
