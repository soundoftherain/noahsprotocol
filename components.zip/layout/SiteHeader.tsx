import { useCallback, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";

interface NavItem {
  label: string;
  href: string;
  type: "anchor" | "route";
}

const navItems: NavItem[] = [
  { label: "Universe", href: "#universe", type: "anchor" },
  { label: "Timeline", href: "#timeline", type: "anchor" },
  { label: "Characters", href: "#characters", type: "anchor" },
  { label: "Ark Coin", href: "#ark-coin", type: "anchor" },
  { label: "Episodes", href: "#episodes", type: "anchor" },
  { label: "Lore Journal", href: "/universe", type: "route" },
];

const scrollToId = (hash: string) => {
  const target = document.querySelector(hash);
  if (target) {
    target.scrollIntoView({ behavior: "smooth", block: "start" });
  }
};

export function SiteHeader() {
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleAnchorClick = useCallback((hash: string) => {
    scrollToId(hash);
  }, []);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 backdrop-blur-lg bg-background/70">
      <div className="mx-auto flex h-20 max-w-6xl items-center justify-between px-6 md:px-8">
        <Link to="/" className="group flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/90 via-primary to-secondary/70 text-background shadow-aurora ring-1 ring-white/30">
            <div
              aria-hidden="true"
              className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-br from-primary/60 via-secondary/40 to-accent/40 blur-2xl opacity-70 animate-glow"
            />
            <span className="text-xl font-bold">N</span>
          </div>
          <div className="leading-tight">
            <p className="text-sm uppercase tracking-[0.4em] text-muted-foreground">
              Noah&apos;s Art
            </p>
            <p className="text-lg font-semibold text-white">
              Evolving Universe
            </p>
          </div>
        </Link>
        <nav className="hidden items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-1 text-sm shadow-aurora md:flex">
          {navItems.map((item) => {
            const isActive =
              item.type === "route"
                ? location.pathname === item.href
                : location.hash === item.href;

            if (item.type === "route") {
              return (
                <Link
                  key={item.label}
                  to={item.href}
                  className={`rounded-full px-4 py-2 transition-all ${
                    isActive
                      ? "bg-white/15 text-white"
                      : "text-muted-foreground hover:bg-white/10 hover:text-white"
                  }`}
                >
                  {item.label}
                </Link>
              );
            }

            return (
              <button
                key={item.label}
                type="button"
                onClick={() => handleAnchorClick(item.href)}
                className="rounded-full px-4 py-2 text-muted-foreground transition-all hover:bg-white/10 hover:text-white"
              >
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="hidden items-center gap-4 md:flex">
          <div className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs uppercase tracking-[0.2em] text-secondary">
            Ark 5.93Ξ
          </div>
          <button className="relative overflow-hidden rounded-full bg-gradient-to-r from-secondary via-primary to-accent px-6 py-2 text-sm font-semibold text-background shadow-aurora transition-transform hover:-translate-y-0.5 focus:outline-none">
            <span className="relative z-10">Connect Wallet</span>
            <span className="absolute inset-0 bg-gradient-to-r from-white/30 via-transparent to-white/30 opacity-0 transition-opacity duration-500 hover:opacity-100" />
          </button>
        </div>
        <button
          className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 text-white md:hidden"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className="sr-only">Toggle menu</span>
          {menuOpen ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>
      {menuOpen ? (
        <div className="border-t border-white/10 bg-background/80 pb-8 pt-4 md:hidden">
          <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6">
            {navItems.map((item) => {
              if (item.type === "route") {
                return (
                  <Link
                    key={item.label}
                    to={item.href}
                    className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-white"
                    onClick={() => setMenuOpen(false)}
                  >
                    {item.label}
                  </Link>
                );
              }

              return (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => {
                    handleAnchorClick(item.href);
                    setMenuOpen(false);
                  }}
                  className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-left text-sm font-semibold text-white"
                >
                  {item.label}
                </button>
              );
            })}
            <button className="rounded-2xl bg-gradient-to-r from-secondary via-primary to-accent px-4 py-3 text-sm font-semibold text-background">
              Connect Wallet
            </button>
          </div>
        </div>
      ) : null}
    </header>
  );
}
